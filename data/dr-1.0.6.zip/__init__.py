import threading

import dr.file
import dr.path
import dr.web
import dr.hash
import dr.windows


def runthread(group=None, target=None, name=None, args=(), kwargs=None,daemon=None):
    process = threading.Thread(group, target, name, args, kwargs,daemon=daemon)
    process.start()


def help(fuc):
    print(helpdict[fuc])


helpdict = {}
