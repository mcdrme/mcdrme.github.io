import os


def makedir(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)
        return True
    else:
        return False