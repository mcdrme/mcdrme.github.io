import win32con
import win32api







dr_windows_messagebox_dict={
"ok":win32con.MB_OK,
"yesno":win32con.MB_YESNO,
"help":win32con.MB_HELP,
"warning":win32con.MB_ICONWARNING,
"error":win32con.MB_ICONERROR,
"question":win32con.MB_ICONQUESTION,
"info":win32con.MB_ICONASTERISK,
"okcancel":win32con.MB_OKCANCEL,
"retry":win32con.MB_RETRYCANCEL,
"yesnocancel":win32con.MB_YESNOCANCEL
}

def messagebox(mode=0,text="",title="",types="ok"):
    win32api.MessageBox(mode,text,title,dr_windows_messagebox_dict[types])
