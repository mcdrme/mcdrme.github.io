import hashlib


def gethash(data, method="md5", ecode="utf-8"):
    if isinstance(data, bytes):
        md5 = hashlib.new(method, data)
    elif isinstance(data, str):
        md5 = hashlib.new(method, data.encode(ecode))
    else:
        raise AssertionError("Data can only be str and bytes(Data只能是str和bytes")
    return md5.hexdigest()
