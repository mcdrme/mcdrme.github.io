import requests


def download(dir, url, headers=None, method="get", **reqparams):
    if method == "get":
        urlfile = requests.get(url, headers=headers, **reqparams)
    elif method == "post":
        urlfile = requests.post(url, headers=headers,**reqparams)
    else:
        raise AssertionError(
            "Method can only be 'get' and 'post'(Method只能是get和post)")
    with open(dir, "wb") as f1:
        f1.write(urlfile.content)

def writefile(dir, mode = "w",data = None):
    with open(dir, mode) as f1:
        if not data == None:
            f1.write(data)

def readfile(dir,mode="t",dcode="utf-8"):
    with open(dir, mode) as f1:
            if "b" in mode:
                return f1.read()
            else:
                return f1.read().decode(dcode)
