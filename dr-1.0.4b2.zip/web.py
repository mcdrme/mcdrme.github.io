import requests
import json


def urldict(url, headers=None, method="get", dcode="utf-8", **reqparams):
    if method == "get":
        urlfile = requests.get(url, headers=headers, **reqparams)
    elif method == "post":
        urlfile = requests.post(url, headers=headers, **reqparams)
    else:
        raise AssertionError(
            "Methods can only be 'get' 'and' post(方法只能是get和post)")
    return json.loads(urlfile.content.decode(dcode))
